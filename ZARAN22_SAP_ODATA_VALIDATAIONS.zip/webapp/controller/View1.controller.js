sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("UI5ADM_SAMPLE_ODATA_S4H.controller.View1", {
onSubmit : function()
{
	
	var v_kunnr = this.getView().byId("id_Kunnr").getValue();
	if (v_kunnr === "") {
                 this.getView().byId("id_Kunnr").setValueState(sap.ui.core.ValueState.Error);  // if the field is empty after change, it will go red
           return "e";
            }

            else {
            	return "n";
                  this.getView().byId("id_Kunnr").setValueState(sap.ui.core.ValueState.None); // if the field is not empty after change, the value state (if any) is removed
            }
},
onInit : function()
{
	var record = 
	{
 	
		Kunnr : "XYZ",
		Name1 : "",
		Ort01 : "",
		Land1 : ""
/*		NavtoItems : [
			{
			 "itemNo" :1,
			 "Mat" : 2
			}
			]
*/			
	};	

	var jsonData = new sap.ui.model.json.JSONModel(record);
 this.getView().byId("id_sf1").setModel(jsonData,"sf")	;
 
},

onDelete : function(oEvent)
{

	var	Kunnr = this.getView().byId("id_Kunnr").getValue();
	var path = "/CustomerSet('" + Kunnr + "')";
	
this.getView().getModel("sap").remove(path,
{
 success: function(OData, response){
  	  // response header
          var hdrMessage = response.headers["sap-message"];
          var hdrMessageObject = JSON.parse(hdrMessage);
  	sap.m.MessageToast.show( hdrMessageObject.message);
 // 		sap.m.MessageToast.show(response);
  },
  error: function(oError){
            var hdrMessage = oError.headers["sap-message"];
          var hdrMessageObject = JSON.parse(hdrMessage);
  	sap.m.MessageToast.show( hdrMessageObject.message);
  
  }

	});
},
onCreate : function(oEvent)
{
	if ( this.onSubmit() !== "e" )
{
/*	
	var record = 
	{
		Kunnr : this.getView().byId("id_Kunnr").getValue(),
		Name1 : this.getView().byId("id_Name1").getValue(),
		Ort01 : this.getView().byId("id_Ort01").getValue(),
		Land1 : this.getView().byId("id_Land1").getValue()
	};
*/	
var record = this.getView().byId("id_sf1").getModel("sf").getData();

this.getView().getModel("sap").create("/CustomerSet",record,
{
  success: function(OData, response){
  	  // response header
          var hdrMessage = response.headers["sap-message"];
          var hdrMessageObject = JSON.parse(hdrMessage);
  	sap.m.MessageToast.show( hdrMessageObject.message);
 // 		sap.m.MessageToast.show(response);
  },
  error: function(oError){
            var hdrMessage = oError.headers["sap-message"];
          var hdrMessageObject = JSON.parse(hdrMessage);
  	sap.m.MessageToast.show( hdrMessageObject.message);
  
  }
  
});

}
}
	});
});